from qgis.core import QgsVectorLayer
import time

def findRootGPKG():
    project_path = QgsProject.instance().fileName()
    root_path = os.path.dirname(project_path)  # Extract directory path
    print(f"Project root path: {root_path}")
    
    # Define the regex to find the correct .gpkg file
    regex = re.compile(f".*{project_code}.*\\.gpkg$")

    # Locate GeoPackages
    gpkgPaths = []
    for dirpath, dirnames, filenames in os.walk(root_path):
        for filename in filenames:
            if re.search(regex, os.path.join(dirpath, filename)):
                gpkgPaths.append(os.path.join(dirpath, filename))
    
    return gpkgPaths


def ChangeGeopackageSource(project_code, gpkgPaths, layer_name):
    #layerList = []
    spltVal = '!!::!!'
    inRgx = "(?i)innerbuffer(.+|_.+|)"
    outRgx = "(?i)outerbuffer(.+|_.+|)"
    new_layer_source = None
    
    for gpkgPath in gpkgPaths:
        # Create a layer pointing to the GeoPackage (any layer will do for listing sublayers)
        layer = QgsVectorLayer(gpkgPath, '', 'ogr')
        # Check if the layer is valid
        if layer.isValid():
            # Get the sublayers (layers within the GeoPackage)
            sublayers = layer.dataProvider().subLayers()
            for sublayer in sublayers:
                splitSub = sublayer.split(spltVal)[1]
                if re.search(inRgx, splitSub) and re.search(inRgx, layer_name):
                   print(f"We are in inner buffer. \nCurrent split is {splitSub}\nCurrent layer is {layer_name}")
                   inBuffName = re.search(inRgx, splitSub).group(0)
                   new_layer_source = f"{gpkgPath}|layername={inBuffName}"
                   print(f"Making new source path for {layer_name}")
                   break  # Exit the loop once a match is found
                   
                elif re.search(outRgx, splitSub) and re.search(outRgx, layer_name):
                   print(f"We are in outer buffer. \nCurrent split is {splitSub}\nCurrent layer is {layer_name}")
                   outBuffName = re.search(outRgx, splitSub).group(0)
                   new_layer_source = f"{gpkgPath}|layername={outBuffName}"
                   print(f"Making new source path for {layer_name}") 
                   break  # Exit the loop once a match is found
                   
                elif splitSub == layer_name:
                    print(f"We are in remaining layers.\nCurrent split is {splitSub}\nCurrent layer is {layer_name}")
                    new_layer_source = f"{gpkgPath}|layername={layer_name}"
                    print(f"Making new source path for {layer_name}")
                    break  # Exit the loop once a match is found
        if new_layer_source:  # If a match is found, stop searching further GeoPackages
            break
                

    project = QgsProject.instance()
    
    # Get the existing layer by name
    old_layer = project.mapLayersByName(layer_name)[0]

    # Set the new data source for the layer
    old_layer.setDataSource(new_layer_source, layer_name, "ogr")

    # Reload the layer
    old_layer.reload()

    # Optionally refresh the map canvas
    iface.mapCanvas().refresh()

    print(f"Layer '{layer_name}' updated successfully.")

project_code = "JSN0223"
layerList = ["Projektomrade","InnerBuffer","OuterBuffer","Orninventering_flygvagar", "Rovfagelinventering_obs", "Rovfagelinventering_obspkt"]

gpkgPaths = findRootGPKG()
 
for layer_name in layerList:
    ChangeGeopackageSource(project_code, gpkgPaths, layer_name)