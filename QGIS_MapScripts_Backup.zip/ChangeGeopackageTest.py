def get_layers_in_geopackage(gpkg_path):
    """
    Function to retrieve the names of layers in a GeoPackage.
    
    Parameters:
    gpkg_path (str): The file path of the GeoPackage.
    
    Returns:
    list: A list of layer names within the GeoPackage.
    """
    uri = f"{gpkg_path}?query=layer_list"
    layer = QgsVectorLayer(uri, "temp_layer", "ogr")
    if not layer.isValid():
        print(f"Failed to open GeoPackage: {gpkg_path}")
        return []
    
    return layer.dataProvider().subLayers()
    
    
project_code = "MAL0999"    
layer_name = "Projektomrade"

project_path = QgsProject.instance().fileName()
root_path = os.path.dirname(project_path)  # Extract directory path

print(f"Project root path: {root_path}")

# Define the regex to find the correct .gpkg file
regex = re.compile(f".*{project_code}.*\\.gpkg$")

gpkgPaths = []

for dirpath, dirnames, filenames in os.walk(root_path):
    for filename in filenames:
        if re.search(regex, os.path.join(dirpath, filename)):
            print("We got a match")
            gpkgPaths.append(os.path.join(dirpath, filename))


layer = QgsVectorLayer(f"{gpkg}?query=layer_list", "temp_layer", "ogr")

from qgis.core import QgsVectorLayer, QgsProviderRegistry

provider = QgsProviderRegistry.instance().providerMetadata("ogr")
sublayers = provider.sublayers(gpkg)

if layer.isValid():
    print("Valid")
else:
    print("Failed")


sublayers = layer.dataProvider().subLayers()

# Check if the layer is valid (i.e., the GeoPackage was opened successfully)
if layer.isValid():
    # Get the sublayers (layers within the GeoPackage)
    sublayers = layer.dataProvider().subLayers()
           
            
            
# Check if the layer exists in this GeoPackage
for gpkg in gpkgPaths:




    uri = f"{gpkg}?query=layer_list"
    layer = QgsVectorLayer(uri, "temp_layer", "ogr")
    if not layer.isValid():
        print(f"Failed to open GeoPackage: {gpkg}")
    
    
    
    gpkg_layers = get_layers_in_geopackage(gpkg)
    
    


if any(layer_name in layer_info for layer_info in gpkg_layers):
    break  # We found the layer in this GeoPackage
    
if matched_gpkg_path and any(layer_name in layer_info for layer_info in gpkg_layers):
break  # Stop searching once the matching layer is found

# If a matching GPKG was found, proceed to update the layer


if matched_gpkg_path:
    print(f"Found matching GPKG: {matched_gpkg_path} containing layer {layer_name}")
    
    # Access the current project instance
    project = QgsProject.instance()
    
    # Get the existing layer by name
    old_layer = project.mapLayersByName(layer_name)[0]
    
    # Build the new layer source using the matched GPKG path
    new_layer_source = f"{matched_gpkg_path}|layername={layer_name}"
    
    # Set the new data source for the layer
    old_layer.setDataSource(new_layer_source, layer_name, "ogr")
    
    # Reload the layer
    old_layer.reload()
    
    # Optionally refresh the map canvas
    iface.mapCanvas().refresh()
    
    print(f"Layer '{layer_name}' updated successfully.")
else:
    print(f"No matching GPKG containing layer {layer_name} found for project code {project_code}.")    