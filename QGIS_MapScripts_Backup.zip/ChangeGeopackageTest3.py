from qgis.core import QgsVectorLayer
from qgis.core import QgsProject
import os
import re

def ChangeGeopackageSource(project_code, gpkgPaths, layer_name):
    #layerList = []
    spltVal = '!!::!!'
    inRgx = "(?i)innerbuffer(.+|_.+|)"
    outRgx = "(?i)outerbuffer(.+|_.+|)"
    new_layer_source = None

    for gpkgPath in gpkgPaths:
        # Create a layer pointing to the GeoPackage (any layer will do for listing sublayers)
        layer = QgsVectorLayer(gpkgPath, '', 'ogr')
        # Check if the layer is valid
        if layer.isValid():
            # Get the sublayers (layers within the GeoPackage)
            sublayers = layer.dataProvider().subLayers()
            for sublayer in sublayers:
                splitSub = sublayer.split(spltVal)[1]
                if re.search(inRgx, splitSub) and re.search(inRgx, layer_name):
                   print(f"We are in inner buffer. \nCurrent split is {splitSub}\nCurrent layer is {layer_name}")
                   inBuffName = re.search(inRgx, splitSub).group(0)
                   new_layer_source = f"{gpkgPath}|layername={inBuffName}"
                   print(f"Making new source path for {layer_name}")
                   break  # Exit the loop once a match is found
                   
                elif re.search(outRgx, splitSub) and re.search(outRgx, layer_name):
                   print(f"We are in outer buffer. \nCurrent split is {splitSub}\nCurrent layer is {layer_name}")
                   outBuffName = re.search(outRgx, splitSub).group(0)
                   new_layer_source = f"{gpkgPath}|layername={outBuffName}"
                   print(f"Making new source path for {layer_name}") 
                   break  # Exit the loop once a match is found
                   
                elif splitSub == layer_name:
                    print(f"We are in remaining layers.\nCurrent split is {splitSub}\nCurrent layer is {layer_name}")
                    new_layer_source = f"{gpkgPath}|layername={layer_name}"
                    print(f"Making new source path for {layer_name}")
                    break  # Exit the loop once a match is found
        if new_layer_source:  # If a match is found, stop searching further GeoPackages
            break
                

    project = QgsProject.instance()

    for layerIndx in range(0, len(project.mapLayersByName(layer_name))): 
        old_layer = project.mapLayersByName(layer_name)[layerIndx]
        old_layer.setDataSource(new_layer_source, layer_name, "ogr")
        old_layer.reload()
        
    print(f"Layer '{layer_name}' updated successfully. Layers with same name was {layerIndx+1}")
    iface.mapCanvas().refresh()


def findRootGPKG():
    project_path = QgsProject.instance().fileName()
    root_path = os.path.dirname(project_path)  # Extract directory path
    print(f"Project root path: {root_path}")
    
    # Define the regex to find the correct .gpkg file
    regex = re.compile(f".*{project_code}.*\\.gpkg$")

    # Locate GeoPackages
    gpkgPaths = []
    for dirpath, dirnames, filenames in os.walk(root_path):
        for filename in filenames:
            if re.search(regex, os.path.join(dirpath, filename)):
                gpkgPaths.append(os.path.join(dirpath, filename))
    
    return gpkgPaths

def update_layout_extent(layout_name, map_name, layer_name):
    # Access the project layout manager
    project = QgsProject.instance()
    
    layers = project.mapLayersByName(layer_name)
    if not layers:
        print(f"Layer '{layer_name}' not found.")
        return
    
    layer = layers[0]  # Get the first layer that matches the name
    
    # Access the layout manager and get the layout by name
    layout = project.layoutManager().layoutByName(layout_name)
    if not layout:
        print(f"Layout '{layout_name}' not found.")
        return
    
    # Find the map in the layout
    layout_map = layout.itemById(map_name)
    if not layout_map:
        print(f"Map '{map_name}' not found in layout.")
        return
        
    # Get the extent of the desired layer
    layer_extent = layer.extent()
    
    # Update the map item to follow the layer extent
    layout_map.zoomToExtent(layer_extent)
    
    # Refresh the layout
    layout.refresh()
    print(f"Layout extent updated to {layer.name()}.")
    
project_code = "JSN0223"
layerList = ["Projektomrade","Ledningsdragning","InnerBuffer","OuterBuffer","Orninventering_flygvagar", "Rovfagelinventering_obs", "Rovfagelinventering_obspkt"]

gpkgPaths = findRootGPKG()
 
for layer_name in layerList:
    ChangeGeopackageSource(project_code, gpkgPaths, layer_name)

update_layout_extent("Layout_Flygvägskarta", "Map 1", "OuterBuffer")