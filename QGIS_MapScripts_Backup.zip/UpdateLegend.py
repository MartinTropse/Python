def update_layout_legend(layout_name, legend_name, map_name):
    # Access the project instance
    project = QgsProject.instance()
    
    # Get the layout by name
    layout = project.layoutManager().layoutByName(layout_name)
    if not layout:
        print(f"Layout '{layout_name}' not found.")
        return

    # Find the legend in the layout by its ID
    legend = layout.itemById(legend_name)
    if not legend:
        print(f"Legend '{legend_name}' not found in layout.")
        return

    # Find the map in the layout (map frame where the layers are displayed)
    map_item = layout.itemById(map_name)
    if not map_item:
        print(f"Map '{map_name}' not found in layout.")
        return

    # Set the legend to follow the layers visible in the map item
    legend.setLinkedMap(map_item)

    # Ensure that all symbols used in the symbology of visible layers are shown
    legend.setAutoUpdateModel(True)  # Automatically update legend with visible layers
    legend.setLegendFilterByMapEnabled(True)  # Filter the legend to only show visible layers within the map extent

    # Refresh the layout to apply the legend changes
    layout.refresh()
    
    print("Legend updated to reflect visible layers in the map extent.")