from qgis.core import QgsProject

def update_layout_extent(layout_name, map_name, layer_name):
    # Access the project layout manager
    project = QgsProject.instance()
    
    layers = project.mapLayersByName(layer_name)
    if not layers:
        print(f"Layer '{layer_name}' not found.")
        return
    
    layer = layers[0]  # Get the first layer that matches the name
    
    # Access the layout manager and get the layout by name
    layout = project.layoutManager().layoutByName(layout_name)
    if not layout:
        print(f"Layout '{layout_name}' not found.")
        return
    
    # Find the map in the layout
    layout_map = layout.itemById(map_name)
    if not layout_map:
        print(f"Map '{map_name}' not found in layout.")
        return
        
    # Get the extent of the desired layer
    layer_extent = layer.extent()
    
    # Update the map item to follow the layer extent
    layout_map.zoomToExtent(layer_extent)
    
    # Refresh the layout
    layout.refresh()
    print(f"Layout extent updated to {layer.name()}.")
    

update_layout_extent("Layout_Flygvägskarta", "Map 1", "OuterBuffer")